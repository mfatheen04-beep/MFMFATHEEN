require('dotenv').config();

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const nodemailer = require('nodemailer');
const Database = require('better-sqlite3');

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

// ---------- App setup ----------
const app = express();

// helmet sets a bunch of protective headers. contentSecurityPolicy is turned
// off here only because this site loads its own inline <style>/<script> and
// local images; if you later move CSS/JS to separate files you can enable it.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: ALLOWED_ORIGIN }));
app.use(express.json({ limit: '20kb' }));

// Serve the KSP website itself (public/ksp_new.html and its images) so the
// whole site + backend can be deployed as a single service.
app.use(express.static(path.join(__dirname, 'public')));

// Limit how often one IP can submit the form, to stop spam/abuse.
const registerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Too many submissions from this device. Please try again later.' }
});

// ---------- Database ----------
const db = new Database(path.join(__dirname, 'data', 'registrations.db'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    gender TEXT NOT NULL,
    email TEXT NOT NULL,
    contact_number TEXT NOT NULL,
    stream TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )
`);

const insertRegistration = db.prepare(`
  INSERT INTO registrations (name, gender, email, contact_number, stream, message)
  VALUES (@name, @gender, @email, @contactNumber, @stream, @message)
`);

// ---------- Email ----------
// Reads SMTP settings from .env. Works with Gmail (using an App Password),
// or any other SMTP provider (SendGrid, Zoho, your host's mail server, etc).
let transporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
} else {
  console.warn(
    '[email] SMTP_HOST / SMTP_USER / SMTP_PASS not set in .env — registrations will still be saved, but no email will be sent.'
  );
}

async function sendNotificationEmail(entry) {
  if (!transporter) return;

  const to = process.env.NOTIFY_EMAIL || process.env.SMTP_USER;
  const subject = `New KSP Registration — ${entry.name}`;
  const text =
    `New registration received on KALPITIYA SCIENCE PROJECT website:\n\n` +
    `Name: ${entry.name}\n` +
    `Gender: ${entry.gender}\n` +
    `Email: ${entry.email}\n` +
    `Contact Number: ${entry.contactNumber}\n` +
    `Stream: ${entry.stream}\n` +
    `Message: ${entry.message}\n`;

  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to,
    replyTo: entry.email,
    subject,
    text
  });
}

// ---------- Validation ----------
function validateRegistration(body) {
  const errors = [];
  const name = String(body.name || '').trim();
  const gender = String(body.gender || '').trim();
  const email = String(body.email || '').trim();
  const contactNumber = String(body.contactNumber || '').trim();
  const stream = String(body.stream || '').trim();
  const message = String(body.message || '').trim();

  if (!name || name.length > 100) errors.push('Please enter a valid name.');
  if (!['Male', 'Female'].includes(gender)) errors.push('Please select a gender.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Please enter a valid email address.');
  if (!/^[0-9+\-\s()]{7,20}$/.test(contactNumber)) errors.push('Please enter a valid contact number.');
  if (!['Biological Science', 'Physical Science'].includes(stream)) errors.push('Please select a stream.');
  if (!message || message.length > 2000) errors.push('Please enter a message (max 2000 characters).');

  return { errors, clean: { name, gender, email, contactNumber, stream, message } };
}

// ---------- Routes ----------
app.get('/api/health', (req, res) => {
  res.json({ ok: true });
});

app.post('/api/register', registerLimiter, async (req, res) => {
  // Honeypot: real users never fill this hidden field in; bots often do.
  if (req.body && req.body.website) {
    return res.status(200).json({ ok: true }); // silently pretend success
  }

  const { errors, clean } = validateRegistration(req.body || {});
  if (errors.length) {
    return res.status(400).json({ error: errors[0], errors });
  }

  try {
    insertRegistration.run(clean);
  } catch (err) {
    console.error('[db] failed to save registration:', err);
    return res.status(500).json({ error: 'Could not save your registration. Please try again.' });
  }

  // Don't let a slow/broken mail server block or fail the user's submission —
  // it's already saved safely in the database either way.
  sendNotificationEmail(clean).catch((err) => {
    console.error('[email] failed to send notification:', err);
  });

  res.status(201).json({ ok: true });
});

// Simple protected endpoint to view saved registrations, e.g. from a browser
// or Postman: GET /api/registrations?key=YOUR_ADMIN_KEY
app.get('/api/registrations', (req, res) => {
  if (!ADMIN_KEY || req.query.key !== ADMIN_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const rows = db.prepare('SELECT * FROM registrations ORDER BY id DESC').all();
  res.json(rows);
});

app.listen(PORT, () => {
  console.log(`KSP backend running on http://localhost:${PORT}`);
});
