# KSP Website Backend

This adds a real backend to your KALPITIYA SCIENCE PROJECT website's
Registration form (the form in the "REGISTRATION" section). When a visitor
submits it, their details are now:

1. **Saved** to a small database file (`data/registrations.db`)
2. **Emailed** to you automatically

## What was fixed in the frontend

Your original form had some broken HTML (a link nested inside the Submit
button, and a duplicated closing tag) which stops forms from working
correctly in some browsers. I fixed:
- The Submit/Reset buttons (were `<button><a>...</a></button>`, now valid buttons)
- A stray extra `</div>` after the Gender field
- The contact email typo `gamil.com` → `gmail.com`
- The submit handler now actually sends data to this backend instead of just
  showing a placeholder message

Nothing else in your design, styling, images, or text was touched.

## Folder structure

```
ksp-backend/
  server.js          <- the backend
  package.json       <- list of dependencies
  .env.example        <- copy this to .env and fill in your details
  public/
    ksp_new.html      <- your website (fixed), served by the backend
  data/               <- registrations.db will be created here automatically
```

## 1. Install (one time)

You need [Node.js](https://nodejs.org) installed (LTS version). Then, in a
terminal, inside the `ksp-backend` folder:

```bash
npm install
```

## 2. Configure email

Copy `.env.example` to a new file named `.env`, then fill it in.

For Gmail specifically:
1. Turn on 2-Step Verification on the Google account you want to send from
2. Create an "App Password": https://myaccount.google.com/apppasswords
3. Put that 16-character app password as `SMTP_PASS` (NOT your normal Gmail password)
4. Set `NOTIFY_EMAIL` to the address that should receive new registrations
   (can be the same Gmail address)

If you skip this step, registrations will still be saved to the database —
you just won't get emails until it's configured.

## 3. Run it locally to test

```bash
npm start
```

Then open `http://localhost:3000/ksp_new.html` in your browser, fill in the
Registration form, and submit. You should see a success message, a new row
appear in the database, and (if email is configured) a notification email.

## 4. View saved registrations any time

Set `ADMIN_KEY` in your `.env` to some long random text, then visit:

```
http://localhost:3000/api/registrations?key=YOUR_ADMIN_KEY
```

(replace with your real domain once deployed). This shows every saved
registration as a list. Keep this key private — anyone with it can view
submissions.

## 5. Put it online (deploy)

The simplest free-tier-friendly options are **Render** or **Railway** —
both can run a Node.js app like this directly from a GitHub repo:

1. Push this whole `ksp-backend` folder to a GitHub repository
2. Create a new "Web Service" on Render (or a new project on Railway),
   connect your repo
3. Set the same variables from your `.env` file in the host's "Environment
   Variables" settings (never upload your real `.env` file itself)
4. Build command: `npm install` — Start command: `npm start`
5. Once deployed, your site will be live at the URL the host gives you,
   e.g. `https://ksp-yourname.onrender.com/ksp_new.html`

Because `server.js` also serves your `public/ksp_new.html`, the website and
the backend live together as one deployed service — no separate hosting
needed for the frontend.

## Notes on safety / spam protection

- A hidden "honeypot" field silently rejects most simple spam bots.
- Submissions are rate-limited (10 per 15 minutes per visitor) to reduce abuse.
- All fields are validated on the server (not just the browser) before saving.
- Your `.env` file (with real email password) is excluded from git via
  `.gitignore` — never share or upload it publicly.
